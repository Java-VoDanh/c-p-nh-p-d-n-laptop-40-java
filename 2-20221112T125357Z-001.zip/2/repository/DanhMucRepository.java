package com.laptopshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.laptopshop.entities.DanhMuc;

public interface DanhMucRepository extends JpaRepository<DanhMuc, Long>{

}
