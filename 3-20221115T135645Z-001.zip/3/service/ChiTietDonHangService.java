package com.laptopshop.service;

import java.util.List;

import com.laptopshop.entities.ChiTietDonHang;

public interface ChiTietDonHangService {
	List<ChiTietDonHang> save(List<ChiTietDonHang> list);
}
